(dp0
Vstatus
p1
L200L
sVbody
p2
V{"users":[{"real_name":"Jonas Sicking (:sicking) PTO Until July 5th","name":"jonas@sicking.cc","email":"jonas@sicking.cc","is_new":false,"groups":[],"last_activity":"2016-06-22T18:18:18Z","can_login":true,"id":9186}]}
p3
sVheaders
p4
(dp5
s.